from django.contrib import admin
from django.urls import path, include
from .views import signup, signin, logout, index, cart, buyitem, deletecart, profile

urlpatterns = [
    path('signup/', signup, name='signup'),
    path('signin/', signin, name='signin'),
    path('', index, name='index'),
    path('cart/', cart, name='cart'),
    path('buyitem/', buyitem, name='buyitem'),
    path('deletecart/', deletecart, name='deletecart'),
    path('profile/', profile, name='profile'),

    path('logout/', logout, name='logout'),
]
