from django.apps import AppConfig


class RegisterappConfig(AppConfig):
    name = 'registerApp'
