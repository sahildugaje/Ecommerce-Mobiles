from django.db import models
from django.contrib.auth.models import User

#
class mobileModel(models.Model):
    mobile_company_name = models.CharField(max_length=20)
    mobile_model_name = models.CharField(max_length=50, blank=True)
    mobile_color = models.CharField(max_length=20, blank=True)
    mobile_ram = models.IntegerField()
    mobile_rom = models.IntegerField(blank=True)
    mobile_price = models.IntegerField()
    mobile_battery_capacity = models.IntegerField(blank=True, default='')
    mobile_display_size = models.FloatField(blank=True, default=0)
    mobile_image_path = models.CharField(max_length=255, blank=True)
    mobile_launch_date = models.DateField(blank=True, help_text='Date of Cash Payment', null=True)
    mobile_url = models.CharField(max_length=255)
    mobile_description = models.TextField(blank=True, max_length=500)


class cartModel(models.Model):
    user_id = models.ForeignKey(User, on_delete=models.CASCADE)
    mobile_id = models.ForeignKey(mobileModel, on_delete=models.CASCADE)
