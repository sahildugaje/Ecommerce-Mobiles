from django.contrib import admin
from .models import mobileModel, cartModel
# Register your models here.

class cartModelShow(admin.ModelAdmin):
    list_display = ['id', 'user_id', 'mobile_id']


class MobileModelShow(admin.ModelAdmin):
    list_display = ['mobile_company_name', 'mobile_model_name', 'mobile_ram', 'mobile_ram', 'mobile_price']
#
admin.site.register(cartModel, cartModelShow)
admin.site.register(mobileModel, MobileModelShow)