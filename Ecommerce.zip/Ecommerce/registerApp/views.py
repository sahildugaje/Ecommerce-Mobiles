from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.contrib.auth.models import auth, User
from django.contrib import messages
from .models import mobileModel, cartModel
from .forms import UserForm
import json
from django.forms import *

# Create your views here.


def signup(request):
    if request.method == 'POST':
        firstname = request.POST['first_name']
        lastname = request.POST['last_name']
        username = request.POST['username']
        email = request.POST['email']
        password = request.POST['password']
        if User.objects.filter(username=username).exists():
            messages.info(request, "Username Already taken")
            return redirect('signup')
        elif User.objects.filter(email=email).exists():
            messages.info(request, "Email Already taken")
            return redirect('signup')
        else:
            user = User.objects.create_user(first_name=firstname,
                                            username=username,
                                            last_name=lastname,
                                            email=email,
                                            password=password)
            user.save()
            print("User Created")
            auth.login(request, user)
        return redirect("index")
    else:
        return render(request, 'signup.html')


def signin(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = auth.authenticate(username=username, password=password)
        if user is not None:
            auth.login(request, user)
            currentUser = request.user
            fullname = {
                'firstname': currentUser.first_name,
                'lastname': currentUser.last_name
            }
            return redirect('index')
        else:
            messages.error(request, "Invalid Credentials!")
            return redirect("signin")
    else:
        return render(request, 'signin.html')


def index(request):
    user = request.user
    mobiles = mobileModel.objects.all()
    cartItemList = cartModel.objects.filter(user_id_id=user.id)
    mobileDataList = []
    for items in cartItemList:
        field_value = items.mobile_id_id
        mobileData = mobileModel.objects.get(id=field_value)
        mobileDataList.append(mobileData)
    mobileDataListPresentInCart = mobileDataList
    lenMobileDataList = len(mobileDataList)
    flagList = []
    for m in mobiles:
        flag = False
        for m_in_c in mobileDataListPresentInCart:
            if m == m_in_c:
                flag = True
        if flag == True:
            flagList.append(1)
        else:
            flagList.append(0)
    ziplist = zip(mobiles,flagList)
    if request.method == 'POST':
        if (request.POST['search']):
            search = request.POST['search']
            searched_data = mobileModel.objects.filter(mobile_company_name__icontains=search) | mobileModel.objects.filter(mobile_model_name__icontains=search) | mobileModel.objects.filter(mobile_ram__icontains=search) | mobileModel.objects.filter(mobile_rom__icontains=search)
            for m in searched_data:
                flag = False
                for m_in_c in mobileDataListPresentInCart:
                    if m == m_in_c:
                        flag = True
                if flag == True:
                    flagList.append(1)
                else:
                    flagList.append(0)
            print(flagList, searched_data)
            ziplist = zip(searched_data, flagList)

            return render(request, 'index.html', {'mobiles': searched_data, 'noofitems':lenMobileDataList, 'ziplist':ziplist})
    return render(request, 'index.html', {'mobiles': mobiles, 'noofitems':lenMobileDataList, 'ziplist':ziplist})

def cart(request):
    if request.method == 'POST':
        user = request.user
        if not request.user.is_authenticated:
            return redirect('signin')
        # if request.POST['cartitem']:
        cartitem = request.POST['cartitem']
        cartId = mobileModel.objects.get(id=cartitem)
        cartInsert = cartModel.objects.create(mobile_id_id=cartitem, user_id_id=int(user.id))
        cartdata = cartModel(request, user_id=user, mobile_id=cartId)
        messages.info(request, f"{cartId.mobile_company_name} {cartId.mobile_model_name}  Added to Cart!")
        return redirect('cart')

    if request.method == 'GET':
        user = request.user
        if request.user.is_authenticated:
            cartItemList = cartModel.objects.filter(user_id_id=user.id)
            # cartItemList = mobileModel.objects.filter(m__id=user.id)
            mobileDataList = []
            for items in cartItemList:
                field_value = items.mobile_id_id
                mobileData = mobileModel.objects.get(id=field_value)
                mobileDataList.append(mobileData)
            lenMobileDataList = len(mobileDataList)
            # cartList = mobileModel.objects.filter(id__in = (mobileDataList))
            return render(request, 'cart.html', {'mobiles':mobileDataList, 'noofitems':lenMobileDataList})

def buyitem(request):
    if request.method == 'POST':
        buyitem = request.POST['buyitem']
        buyItemId = mobileModel.objects.get(id=buyitem)
        buyItemData = {
            'itemDetails': buyItemId
        }
        print(buyItemData)
        return render(request, 'buyitem.html', buyItemData)


def deletecart(request):
    if request.method == 'POST':
        deleteItemId = request.POST['deleteid']
        deleteUserId = request.user
        #return HttpResponse(deleteItemId)
        deleteInstance = cartModel.objects.filter(mobile_id_id=deleteItemId) & cartModel.objects.filter(user_id_id=deleteUserId)
        print('deleteInstance:',deleteInstance)
        deleteInstance.delete()
        cartId = mobileModel.objects.get(id=deleteItemId)
        messages.info(request, f"{cartId.mobile_company_name} {cartId.mobile_model_name}  Removed From Cart!")
        return redirect('cart')

def profile(request):
    if request.method == 'POST':
        username = request.POST['username']
        email = request.POST['email']
        first_name = request.POST['first_name']
        last_name = request.POST['last_name']
        u_form = UserForm(request.POST, instance=request.user)
        if u_form.is_valid():
            u_form.save()
            messages.info(request,'Updated Profile Successfully')

        else:
            messages.info(request,'Username or Email already Registered')
    user = request.user
    print(user)
    userData = User.objects.filter(id=user.id).values('username','first_name','last_name','password','email')
    userDataToSend = {
        'userData':userData
    }
    print(userDataToSend['userData'][0]['last_name'])
    return render(request,'profile.html', userDataToSend)


def logout(request):
    auth.logout(request)
    return redirect(index)
